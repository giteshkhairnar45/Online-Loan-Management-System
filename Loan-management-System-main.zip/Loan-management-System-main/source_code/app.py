import os
import pandas as pd
import numpy as np
import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
from LoanApprovalRandomFor import LoanApprovalSystem
from app.bank_scraper import scrape_bank_data

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Initialize and train the ML model
loan_system = LoanApprovalSystem()
loan_system.train_machine()

# Define form fields based on the ML model
form_fields = [
    {"name": "no_of_dependents", "label": "Number of Dependents", "type": "number", "min": 0, "max": 10},
    {"name": "education", "label": "Education", "type": "select", "options": [{"value": 0, "label": "Non-Graduate"}, {"value": 1, "label": "Graduate"}]},
    {"name": "self_employed", "label": "Self Employed", "type": "select", "options": [{"value": 0, "label": "No"}, {"value": 1, "label": "Yes"}]},
    {"name": "income_annum", "label": "Annual Income (₹)", "type": "number", "min": 100000, "max": 10000000},
    {"name": "loan_amount", "label": "Loan Amount (₹)", "type": "number", "min": 100000, "max": 50000000},
    {"name": "loan_term", "label": "Loan Term (Years)", "type": "number", "min": 1, "max": 30},
    {"name": "cibil_score", "label": "CIBIL Score", "type": "number", "min": 300, "max": 900},
    {"name": "residential_assets_value", "label": "Residential Assets Value (₹)", "type": "number", "min": 0, "max": 100000000},
    {"name": "commercial_assets_value", "label": "Commercial Assets Value (₹)", "type": "number", "min": 0, "max": 100000000},
    {"name": "luxury_assets_value", "label": "Luxury Assets Value (₹)", "type": "number", "min": 0, "max": 100000000},
    {"name": "bank_asset_value", "label": "Bank Assets Value (₹)", "type": "number", "min": 0, "max": 100000000}
]

# Context processor to provide the current year to all templates
@app.context_processor
def inject_current_year():
    return {'current_year': datetime.datetime.now().year}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/eligibility')
def eligibility():
    return render_template('eligibility.html', form_fields=form_fields)

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        try:
            # Get form data
            form_data = {}
            for field in form_fields:
                value = request.form.get(field['name'])
                if value is None or value == '':
                    return jsonify({'error': f"Missing field: {field['name']}"})
                form_data[field['name']] = float(value)
            
            # Create a DataFrame with the input data
            input_df = pd.DataFrame([form_data])
            
            # Ensure input features match the training features
            training_features = loan_system.TrainingDatasetFeatures.columns.tolist()
            for column in training_features:
                if column not in input_df.columns:
                    input_df[column] = 0  # Default value for missing columns
            
            # Make sure the DataFrame only has the columns used in training, in the same order
            input_df = input_df[training_features]
            
            # Make prediction from ML model
            ml_prediction = loan_system.rf.predict(input_df)[0]
            
            # Apply rule-based logic to override ML model if necessary
            # This ensures we reject loans in certain clear scenarios
            final_prediction = ml_prediction
            
            # Rule-based rejection criteria
            if form_data['cibil_score'] < 600:
                final_prediction = 1  # Force reject if CIBIL score is too low
            elif form_data['loan_amount'] > form_data['income_annum'] * 3:
                final_prediction = 1  # Force reject if loan amount is too high compared to income
            elif form_data['loan_term'] > 20:
                final_prediction = 1  # Force reject if loan term is too long
            
            # Create explanation based on form data
            explanation = get_explanation(form_data, final_prediction)
            
            # Store form data and result in session for bank recommendations
            session['loan_data'] = {
                'form_data': form_data,
                'eligible': int(final_prediction) == 0,
                'cibil_score': form_data['cibil_score'],
                'loan_amount': form_data['loan_amount'],
                'income': form_data['income_annum']
            }
            
            return jsonify({
                'eligible': int(final_prediction) == 0,  # 0 means eligible, 1 means not eligible
                'explanation': explanation
            })
        except Exception as e:
            return jsonify({'error': str(e)})

def get_explanation(data, prediction):
    explanations = []
    
    # Eligibility criteria explanations
    if prediction == 0:  # Eligible
        explanations.append("Congratulations! You are eligible for a loan.")
        
        if data['cibil_score'] >= 750:
            explanations.append("You have an excellent CIBIL score.")
        elif data['cibil_score'] >= 650:
            explanations.append("You have a good CIBIL score.")
            
        if data['income_annum'] >= 5000000:
            explanations.append("Your income is well above the required threshold.")
        elif data['income_annum'] >= 3000000:
            explanations.append("Your income meets the required threshold.")
            
        if data['loan_amount'] <= 10000000:
            explanations.append("Your requested loan amount is within acceptable range.")
    else:  # Not Eligible
        explanations.append("We're sorry, but you are not eligible for a loan at this time.")
        
        if data['cibil_score'] < 600:
            explanations.append("Your CIBIL score of " + str(int(data['cibil_score'])) + " is below our minimum threshold of 600.")
            
        if data['income_annum'] < 3000000:
            explanations.append("Your annual income of ₹" + str(int(data['income_annum'])) + " is below our required threshold of ₹3,000,000.")
            
        if data['loan_amount'] > data['income_annum'] * 3:
            explanations.append("Your requested loan amount of ₹" + str(int(data['loan_amount'])) + " exceeds 3 times your annual income (₹" + str(int(data['income_annum'])) + ").")
            
        if data['loan_term'] > 20:
            explanations.append("Your requested loan term of " + str(int(data['loan_term'])) + " years exceeds our maximum offering of 20 years.")
            
    return explanations

@app.route('/banks')
def banks_page():
    # Get banks data using the scraper
    banks_data = scrape_bank_data()
    
    # Check if we have user loan data in session
    if 'loan_data' in session:
        loan_data = session['loan_data']
        
        # Score and sort banks based on user eligibility
        for bank in banks_data:
            bank['score'] = calculate_bank_score(bank, loan_data)
        
        # Sort banks by score (higher is better)
        banks_data = sorted(banks_data, key=lambda x: x['score'], reverse=True)
        
        # Pass the eligible flag to the template
        eligible = loan_data.get('eligible', None)
        return render_template('banks.html', banks=banks_data, eligible=eligible, from_prediction=True)
    
    # If no session data, just display banks without sorting
    return render_template('banks.html', banks=banks_data, from_prediction=False)

def calculate_bank_score(bank, loan_data):
    """Calculate a score for each bank based on user's loan data"""
    score = 100
    
    # If user is not eligible, prioritize banks with lower CIBIL requirements
    if not loan_data.get('eligible', True):
        if 'min_cibil' in bank and bank['min_cibil'] > loan_data.get('cibil_score', 0):
            score -= 50
    
    # Adjust score based on interest rate (lower is better)
    score -= bank['interest_rate'] * 5
    
    # Boost score for more trustable banks
    score += bank['trustability'] / 2
    
    # Government banks might be better for certain types of loans
    if bank['type'] == 'GOV' and loan_data.get('loan_amount', 0) > 5000000:
        score += 10
        
    return score

@app.route('/calculator')
def calculator():
    return render_template('calculator.html')

@app.route('/guide')
def guide():
    return render_template('guide.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/submit-contact', methods=['POST'])
def submit_contact():
    if request.method == 'POST':
        # In a real application, you would save this data to a database
        # and/or send an email notification
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        
        # For demo purposes, we'll just redirect back to the contact page
        # with a success message
        flash('Thank you for your message! We will get back to you soon.', 'success')
        return redirect(url_for('contact'))

if __name__ == '__main__':
    app.run(debug=True) 