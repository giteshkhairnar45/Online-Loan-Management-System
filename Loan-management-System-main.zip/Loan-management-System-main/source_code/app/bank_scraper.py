import requests
from bs4 import BeautifulSoup
import time
import random

def scrape_bank_data():
    """
    Scrape real-time bank interest rates and information
    In a real implementation, this would scrape from actual bank websites
    For demo purposes, we'll return structured mock data
    """
    try:
        # Simulated scraping delay
        time.sleep(0.5)
        
        # In a real implementation, you would fetch data from bank websites
        # Example:
        # response = requests.get('https://www.bankwebsite.com/interest-rates')
        # soup = BeautifulSoup(response.text, 'html.parser')
        # ... extract data from soup ...
        
        # For demo, return mock data with slight randomization to simulate "live" data
        banks = [
            {
                "name": "State Bank of India",
                "type": "GOV",
                "interest_rate": round(8.3 + random.uniform(0, 0.5), 2),
                "trustability": 95,
                "loan_types": ["Home", "Personal", "Education", "Business"],
                "website": "https://sbi.co.in",
                "processing_fee": "0.5%",
                "min_cibil": 650
            },
            {
                "name": "HDFC Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.0 + random.uniform(0, 0.5), 2),
                "trustability": 90,
                "loan_types": ["Home", "Personal", "Business", "Auto"],
                "website": "https://www.hdfcbank.com",
                "processing_fee": "1%",
                "min_cibil": 700
            },
            {
                "name": "ICICI Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.3 + random.uniform(0, 0.5), 2),
                "trustability": 88,
                "loan_types": ["Home", "Personal", "Auto", "Education"],
                "website": "https://www.icicibank.com",
                "processing_fee": "1.25%",
                "min_cibil": 680
            },
            {
                "name": "Punjab National Bank",
                "type": "GOV",
                "interest_rate": round(8.5 + random.uniform(0, 0.4), 2),
                "trustability": 87,
                "loan_types": ["Home", "Personal", "Education", "Agriculture"],
                "website": "https://www.pnbindia.in",
                "processing_fee": "0.5%",
                "min_cibil": 620
            },
            {
                "name": "Axis Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.5 + random.uniform(0, 0.4), 2),
                "trustability": 85,
                "loan_types": ["Home", "Personal", "Business"],
                "website": "https://www.axisbank.com",
                "processing_fee": "1.5%",
                "min_cibil": 700
            },
            {
                "name": "Bank of Baroda",
                "type": "GOV",
                "interest_rate": round(8.4 + random.uniform(0, 0.3), 2),
                "trustability": 86,
                "loan_types": ["Home", "Personal", "Agriculture"],
                "website": "https://www.bankofbaroda.in",
                "processing_fee": "0.75%",
                "min_cibil": 640
            },
            {
                "name": "Kotak Mahindra Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.6 + random.uniform(0, 0.4), 2),
                "trustability": 84,
                "loan_types": ["Home", "Personal", "Business", "Auto"],
                "website": "https://www.kotak.com",
                "processing_fee": "1.25%",
                "min_cibil": 710
            },
            {
                "name": "Union Bank of India",
                "type": "GOV",
                "interest_rate": round(8.6 + random.uniform(0, 0.3), 2),
                "trustability": 83,
                "loan_types": ["Home", "Personal", "Education"],
                "website": "https://www.unionbankofindia.co.in",
                "processing_fee": "0.5%",
                "min_cibil": 630
            },
            {
                "name": "Yes Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.8 + random.uniform(0, 0.4), 2),
                "trustability": 75,
                "loan_types": ["Home", "Personal", "Business"],
                "website": "https://www.yesbank.in",
                "processing_fee": "1.5%",
                "min_cibil": 720
            },
            {
                "name": "Canara Bank", 
                "type": "GOV",
                "interest_rate": round(8.7 + random.uniform(0, 0.3), 2),
                "trustability": 82,
                "loan_types": ["Home", "Personal", "Education", "Agriculture"],
                "website": "https://www.canarabank.com",
                "processing_fee": "0.5%",
                "min_cibil": 650
            },
            {
                "name": "IndusInd Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.4 + random.uniform(0, 0.5), 2),
                "trustability": 81,
                "loan_types": ["Home", "Personal", "Business", "Auto"],
                "website": "https://www.indusind.com",
                "processing_fee": "1.25%",
                "min_cibil": 710
            },
            {
                "name": "Bank of India",
                "type": "GOV",
                "interest_rate": round(8.5 + random.uniform(0, 0.4), 2),
                "trustability": 80,
                "loan_types": ["Home", "Personal", "Education", "Agriculture"],
                "website": "https://www.bankofindia.co.in",
                "processing_fee": "0.5%",
                "min_cibil": 630
            },
            {
                "name": "Federal Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.2 + random.uniform(0, 0.4), 2),
                "trustability": 79,
                "loan_types": ["Home", "Personal", "Business"],
                "website": "https://www.federalbank.co.in",
                "processing_fee": "1%",
                "min_cibil": 680
            },
            {
                "name": "IDBI Bank",
                "type": "GOV",
                "interest_rate": round(8.8 + random.uniform(0, 0.3), 2),
                "trustability": 78,
                "loan_types": ["Home", "Personal", "Education"],
                "website": "https://www.idbibank.in",
                "processing_fee": "0.75%",
                "min_cibil": 640
            },
            {
                "name": "RBL Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.9 + random.uniform(0, 0.5), 2),
                "trustability": 74,
                "loan_types": ["Home", "Personal", "Business"],
                "website": "https://www.rblbank.com",
                "processing_fee": "1.5%",
                "min_cibil": 720
            },
            {
                "name": "Central Bank of India",
                "type": "GOV",
                "interest_rate": round(8.6 + random.uniform(0, 0.3), 2),
                "trustability": 77,
                "loan_types": ["Home", "Personal", "Agriculture"],
                "website": "https://www.centralbankofindia.co.in",
                "processing_fee": "0.5%",
                "min_cibil": 620
            },
            {
                "name": "South Indian Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.3 + random.uniform(0, 0.4), 2),
                "trustability": 76,
                "loan_types": ["Home", "Personal", "Business", "Education"],
                "website": "https://www.southindianbank.com",
                "processing_fee": "1.25%",
                "min_cibil": 670
            },
            {
                "name": "Indian Overseas Bank",
                "type": "GOV",
                "interest_rate": round(8.7 + random.uniform(0, 0.3), 2),
                "trustability": 75,
                "loan_types": ["Home", "Personal", "Education", "Agriculture"],
                "website": "https://www.iob.in",
                "processing_fee": "0.6%",
                "min_cibil": 630
            },
            {
                "name": "Bandhan Bank",
                "type": "PRIVATE",
                "interest_rate": round(9.7 + random.uniform(0, 0.4), 2),
                "trustability": 73,
                "loan_types": ["Home", "Personal", "Business", "Microfinance"],
                "website": "https://www.bandhanbank.com",
                "processing_fee": "1.25%",
                "min_cibil": 650
            },
            {
                "name": "UCO Bank",
                "type": "GOV",
                "interest_rate": round(8.8 + random.uniform(0, 0.3), 2),
                "trustability": 72,
                "loan_types": ["Home", "Personal", "Education"],
                "website": "https://www.ucobank.com",
                "processing_fee": "0.5%",
                "min_cibil": 620
            }
        ]
        
        return banks
    except Exception as e:
        print(f"Error scraping bank data: {str(e)}")
        # Return fallback data if scraping fails
        return [
            {"name": "State Bank of India", "type": "GOV", "interest_rate": 8.5, "trustability": 95},
            {"name": "HDFC Bank", "type": "PRIVATE", "interest_rate": 9.2, "trustability": 90}
        ]
        
if __name__ == "__main__":
    # Test the scraper
    banks = scrape_bank_data()
    for bank in banks:
        print(f"{bank['name']} - Interest Rate: {bank['interest_rate']}%") 