document.addEventListener('DOMContentLoaded', function() {
    // Mobile navigation toggle
    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
        
        // Close mobile menu when a link is clicked
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 768) {
                    navLinks.classList.remove('active');
                }
            });
        });
    }
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 768 && 
            navLinks && 
            navLinks.classList.contains('active') && 
            !e.target.closest('.main-nav')) {
            navLinks.classList.remove('active');
        }
    });
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            
            if (href !== '#') {
                e.preventDefault();
                
                const targetElement = document.querySelector(href);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 70, // Adjust for header height
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
    
    // Handle form submissions with AJAX (if available)
    const predictionForm = document.getElementById('prediction-form');
    
    if (predictionForm) {
        predictionForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = this;
            const submitBtn = form.querySelector('button[type="submit"]');
            const formData = new FormData(form);
            const resultContainer = document.getElementById('prediction-result');
            
            if (submitBtn && resultContainer) {
                // Disable button and show loading state
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                resultContainer.innerHTML = '';
                
                try {
                    const response = await fetch('/predict', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const data = await response.json();
                    
                    if (data.error) {
                        resultContainer.innerHTML = `
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-circle"></i> ${data.error}
                            </div>
                        `;
                    } else {
                        // Display the result
                        const resultClass = data.eligible ? 'success' : 'danger';
                        const resultIcon = data.eligible ? 'check-circle' : 'times-circle';
                        const explanationList = data.explanation.map(exp => `<li>${exp}</li>`).join('');
                        
                        resultContainer.innerHTML = `
                            <div class="prediction-card ${resultClass}-card">
                                <div class="prediction-header">
                                    <i class="fas fa-${resultIcon}"></i>
                                    <h3>${data.eligible ? 'Eligible for Loan' : 'Not Eligible for Loan'}</h3>
                                </div>
                                <div class="prediction-body">
                                    <ul>${explanationList}</ul>
                                </div>
                                <div class="prediction-actions">
                                    ${data.eligible ? 
                                        '<a href="/banks" class="btn btn-primary">Find Best Loan Offers</a>' : 
                                        '<a href="/guide" class="btn btn-secondary">How to Improve Eligibility</a>'}
                                </div>
                            </div>
                        `;
                    }
                } catch (error) {
                    resultContainer.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> An error occurred. Please try again.
                        </div>
                    `;
                } finally {
                    // Re-enable button
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = 'Predict Eligibility';
                    
                    // Scroll to result
                    if (resultContainer.innerHTML !== '') {
                        resultContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                }
            }
        });
    }
    
    // Initialize loan calculator functionality
    const loanCalculator = document.getElementById('loan-calculator');
    
    if (loanCalculator) {
        const calculateBtn = loanCalculator.querySelector('#calculate-btn');
        const resultDiv = document.getElementById('calculator-result');
        
        if (calculateBtn && resultDiv) {
            calculateBtn.addEventListener('click', function() {
                const loanAmount = parseFloat(document.getElementById('loan-amount').value);
                const interestRate = parseFloat(document.getElementById('interest-rate').value);
                const loanTerm = parseInt(document.getElementById('loan-term').value);
                
                if (isNaN(loanAmount) || isNaN(interestRate) || isNaN(loanTerm)) {
                    resultDiv.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> Please enter valid values for all fields.
                        </div>
                    `;
                    return;
                }
                
                // Calculate monthly EMI
                const monthlyRate = interestRate / 100 / 12;
                const totalPayments = loanTerm * 12;
                
                const x = Math.pow(1 + monthlyRate, totalPayments);
                const monthlyEMI = (loanAmount * x * monthlyRate) / (x - 1);
                
                const totalAmount = monthlyEMI * totalPayments;
                const totalInterest = totalAmount - loanAmount;
                
                resultDiv.innerHTML = `
                    <div class="card">
                        <div class="card-header">
                            <h3>Loan EMI Details</h3>
                        </div>
                        <div class="card-body">
                            <div class="result-item">
                                <span>Monthly EMI:</span>
                                <strong>₹${monthlyEMI.toFixed(2)}</strong>
                            </div>
                            <div class="result-item">
                                <span>Total Interest:</span>
                                <strong>₹${totalInterest.toFixed(2)}</strong>
                            </div>
                            <div class="result-item">
                                <span>Total Amount:</span>
                                <strong>₹${totalAmount.toFixed(2)}</strong>
                            </div>
                        </div>
                    </div>
                `;
            });
        }
    }
    
    // Bank filtering functionality
    const bankFilters = document.getElementById('bank-filters');
    
    if (bankFilters) {
        const filterInputs = bankFilters.querySelectorAll('input[name="bank-type"], #sort-by');
        const bankCards = document.querySelectorAll('.bank-card');
        
        // Initial filter/sort on page load
        const initialBankType = document.querySelector('input[name="bank-type"]:checked')?.value || 'all';
        const initialSortBy = document.getElementById('sort-by')?.value || 'interest-low';
        filterBanks(bankCards, initialBankType, initialSortBy);
        
        // Apply filters on change
        filterInputs.forEach(input => {
            input.addEventListener('change', () => {
                // Get filter values
                const bankType = document.querySelector('input[name="bank-type"]:checked')?.value || 'all';
                const sortBy = document.getElementById('sort-by')?.value || 'interest-low';
                
                // Apply filters
                filterBanks(bankCards, bankType, sortBy);
            });
        });
    }

    // Handle flash messages
    const closeFlashButtons = document.querySelectorAll('.close-flash');
    
    closeFlashButtons.forEach(button => {
        button.addEventListener('click', function() {
            const flashMessage = this.parentElement;
            flashMessage.style.animation = 'fadeOut 0.5s forwards';
            
            setTimeout(() => {
                flashMessage.remove();
            }, 500);
        });
    });

    // Auto-dismiss flash messages after 5 seconds
    const flashMessages = document.querySelectorAll('.flash-message');
    
    flashMessages.forEach(message => {
        setTimeout(() => {
            if (message) {
                message.style.animation = 'fadeOut 0.5s forwards';
                
                setTimeout(() => {
                    if (message.parentElement) {
                        message.remove();
                    }
                }, 500);
            }
        }, 5000);
    });

    // Handle hero image fallback
    const heroImage = document.querySelector('.hero-image img');
    if (heroImage) {
        heroImage.onerror = function() {
            // Create an SVG illustration as fallback
            const svgContent = `
            <svg xmlns="http://www.w3.org/2000/svg" width="500" height="400" viewBox="0 0 800 600">
                <style>
                    .primary { fill: #0d6efd; }
                    .secondary { fill: #4a6bfd; }
                    .light { fill: #e6eeff; }
                    .medium { fill: #ccdcff; }
                    [data-theme="dark"] .light { fill: #2a3a5a; }
                    [data-theme="dark"] .medium { fill: #1f2c48; }
                </style>
                <rect x="100" y="100" width="600" height="400" rx="20" class="light" />
                <rect x="150" y="150" width="200" height="300" rx="10" class="medium" />
                <rect x="400" y="150" width="250" height="150" rx="10" class="medium" />
                <rect x="400" y="330" width="250" height="120" rx="10" class="medium" />
                <circle cx="250" cy="250" r="60" class="primary" />
                <rect x="450" y="180" width="150" height="20" rx="5" class="primary" />
                <rect x="450" y="220" width="100" height="20" rx="5" class="secondary" />
                <rect x="450" y="260" width="180" height="20" rx="5" class="primary" />
                <rect x="450" y="350" width="150" height="20" rx="5" class="primary" />
                <rect x="450" y="390" width="120" height="20" rx="5" class="secondary" />
            </svg>
            `;
            
            // Convert SVG to data URL
            const svgBlob = new Blob([svgContent], { type: 'image/svg+xml' });
            const url = URL.createObjectURL(svgBlob);
            this.src = url;
        };
    }
});

function filterBanks(bankCards, bankType, sortBy) {
    console.log('Filtering banks - Type:', bankType, 'Sort By:', sortBy);
    
    // Get the contact card and bank container
    const contactCard = document.querySelector('.contact-card');
    const bankContainer = document.querySelector('.bank-cards-container');
    
    if (!bankContainer) return;
    
    // First filter by bank type (excluding contact card)
    let filteredBanks = Array.from(bankCards).filter(card => card !== contactCard);
    
    if (bankType !== 'all') {
        filteredBanks = filteredBanks.filter(card => {
            const cardType = card.dataset.type;
            return cardType === bankType;
        });
    }
    
    // Then sort based on criteria
    filteredBanks.sort((a, b) => {
        if (sortBy === 'interest-low') {
            return parseFloat(a.dataset.interestRate) - parseFloat(b.dataset.interestRate);
        } else if (sortBy === 'interest-high') {
            return parseFloat(b.dataset.interestRate) - parseFloat(a.dataset.interestRate);
        } else if (sortBy === 'trustability') {
            return parseFloat(b.dataset.trustability) - parseFloat(a.dataset.trustability);
        } else if (sortBy === 'score') {
            return parseFloat(b.dataset.score || 0) - parseFloat(a.dataset.score || 0);
        }
        return 0;
    });
    
    console.log('Filtered banks count:', filteredBanks.length);
    
    // Clear the container except for contact card
    while (bankContainer.firstChild) {
        bankContainer.removeChild(bankContainer.firstChild);
    }
    
    // Add contact card back first if it exists
    if (contactCard) {
        bankContainer.appendChild(contactCard);
    }
    
    // Add filtered banks in the sorted order
    filteredBanks.forEach(card => {
        bankContainer.appendChild(card);
    });
    
    // Show/hide no results message
    const noResults = document.getElementById('no-results');
    if (noResults) {
        noResults.style.display = filteredBanks.length === 0 ? 'block' : 'none';
    }
} 