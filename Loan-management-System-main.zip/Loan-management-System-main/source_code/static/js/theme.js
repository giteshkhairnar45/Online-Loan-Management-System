document.addEventListener('DOMContentLoaded', function() {
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', () => {
            // Get the current theme
            const currentTheme = document.documentElement.getAttribute('data-theme');
            
            // Toggle the theme
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            // Apply the new theme
            document.documentElement.setAttribute('data-theme', newTheme);
            
            // Save the theme preference
            localStorage.setItem('theme', newTheme);
        });
    }
}); 