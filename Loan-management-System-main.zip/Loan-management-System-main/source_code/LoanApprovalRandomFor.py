from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score as sklearn_accuracy_score
import pandas as pd
class LoanApprovalSystem:
    def __init__(self):
        self.TrainingDatasetFeatures = pd.read_csv('XTraining_dataset.csv')
        self.TrainingDatasetTarget = pd.read_csv('YTraining_dataset.csv')
        self.TestingDatasetFeatures = pd.read_csv('XTesting_dataset.csv')
        self.TestingDatasetTarget = pd.read_csv('YTesting_dataset.csv')
        self.rf = RandomForestClassifier(n_estimators=100, random_state=42)

    def train_machine(self):
        self.X_train = self.TrainingDatasetFeatures.iloc[:, :]
        self.Y_train = self.TrainingDatasetTarget.iloc[:, -1]
        self.rf.fit(self.X_train, self.Y_train.values.ravel())

    def test_machine(self):
        self.X_test = self.TestingDatasetFeatures.iloc[:, :]
        self.Y_test = self.TestingDatasetTarget.iloc[:, -1]
        self.Y_pred = self.rf.predict(self.X_test)
        print(self.Y_pred)

    def accuracy_score(self):
        accuracy = sklearn_accuracy_score(self.Y_test, self.Y_pred)
        print(f'Accuracy: {accuracy * 100:.2f}%')


    